      </div><!-- end: textarea -->
    </div><!-- end: contentarea -->

	  <div id="bottomarea">
	    <p>
	      <a href="http://www.insanefactory.com/if-svnadmin/?pk_campaign=iFSVNAdmin-Footer" target="_blank">iF.SVNAdmin <?php AppVersion(); ?></a> -
	      &copy; 2009-2012 <a href="http://www.insanefactory.com/?pk_campaign=iFSVNAdmin-Footer" target="_blank">insaneFactory.com</a>
	    </p>
	  </div>

  </div><!-- End id=main -->
  <script language="Javascript" type="text/javascript">highlightDatatables();</script>
</body>
</html>